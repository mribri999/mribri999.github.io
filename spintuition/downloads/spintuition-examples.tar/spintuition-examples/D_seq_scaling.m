% 1. Initialize sequence object and set system limits
system = mr.opts('MaxGrad', 40, 'GradUnit', 'mT/m', ...
                 'MaxSlew', 150, 'SlewUnit', 'T/m/s', ...
                 'rfRingdownTime', 20e-6, ...
                 'rfDeadTime', 10e-6, ...
                 'adcDeadTime', 10e-6);

seq = mr.Sequence(system);

seq.setDefinition('#SimmrDescription','Scaling Example:  The spins matrix assumes a 25cm FOV.  This sequence uses 25cm FOV, 1mm resolution, 1ms readout, with 2mm thick slice.  The scaling is set to 4/250, so in a 5x1x5 matrix, you should see 4 cycles accrue across the FOV (250 in the unscaled), over the readout plateau.  After scaling, the slice is about 120mm, so 1/2 of the 25cm FOV.')
seq.setDefinition('# SimmrMatrixSize',' 5 1 5')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrView',' obl')
seq.setDefinition('# SimmrGradScale',' 0.016');   % (4/250)
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')


% 2. Define sequence parameters
sliceThickness = 2e-3;     % 2 mm slice thickness
fov = 250e-3;              % 250 mm (25 cm) Field of View
resolution = 1e-3;         % 1 mm spatial resolution
readoutDuration = 1e-3;    % 1 ms readout duration
flipAngle = 90;            % 90-degree excitation

% 3. Calculate Imaging Matrix Size and Readout Gradients
Nx = fov / resolution;      % 250 read samples/matrix size
kWidth = 1 / resolution;    % Total k-space span (m^-1)

% Slice-selection RF pulse (sinc excitation)
[rf, gz] = mr.makeSincPulse(flipAngle * pi / 180, system, ...
                            'Duration', 2e-3, ...
                            'SliceThickness', sliceThickness, ...
                            'Apodization', 0.5, ...
                            'timeBwProduct', 4);

% Slice refocusing gradient
gzReph = mr.makeTrapezoid('z', system, ...
                          'Area', -gz.area / 2, ...
                          'Duration', 1e-3);


% Readout gradient and ADC acquisition block
gx = mr.makeTrapezoid('x', system, ...
                      'FlatArea', kWidth, ...
                      'FlatTime', readoutDuration);

% Pre-winder gradient along X to dephase k-space prior to readout
% Dephase to -kMax (-kWidth/2)
gxPre = mr.makeTrapezoid('x', system, ...
                         'Area', -gx.area/2, ...
                         'Duration', 1e-3);

adc = mr.makeAdc(Nx, system, ...
                 'Duration', readoutDuration, ...
                 'Delay', gx.riseTime);

% 4. Assemble Sequence Blocks

% Block 1: Excitation RF and Slice Selection Gradient
seq.addBlock(rf, gz);

% Block 2: Simultaneous Slice Refocusing (Z) and Pre-phasing (X)
seq.addBlock(gzReph, gxPre);

% Block 3: Readout Gradient and ADC Acquisition
seq.addBlock(gx, adc);


% Validate sequence timing
[ok, error_report] = seq.checkTiming();
if ok
    fprintf("Sequence timing check passed successfully!\n");
else
    fprintf("Timing errors detected:\n");
    disp(error_report);
end

% Plot sequence diagram
seq.plot();

% Write to .seq file
outputFileName = ('D_seq_scaling.seq');
seq.write(outputFileName);
fprintf('Successfully saved sequence to file: %s\n', outputFileName);


