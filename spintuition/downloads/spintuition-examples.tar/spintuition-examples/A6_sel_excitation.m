% Clear workspace
clear all; clc;

% Initialize Pulseq system limits
% (Modify these limits according to your specific scanner vendor/model)
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, ...
              'rfDeadTime', 100e-6, ...
              'adcDeadTime', 10e-6);

% Initialize sequence object
seq = mr.Sequence(sys);

seq.setDefinition('#SimmrDescription', 'Selective Excitation:  With a z gradient, only some spins are excited - these are "on resonance.".  A refocusing gradient realigns excited spins.  ')
seq.setDefinition('# SimmrMatrixSize',' 3 1 7')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrDfr', '0.0')
seq.setDefinition('# SimmrView',' obl')
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')

%% Parameters
sliceThickness = 2.5e-3;   % 2.5mm slice thickness
rfDuration = 2e-3;        % 2 ms RF duration
timeBwProduct = 4;        % Time-Bandwidth Product for the sinc pulse

%% 1. Create Sinc RF Pulse
% Rotation around -y axis corresponds to a 270 degree (3*pi/2) phase shift.
% (Note: 0 = +x, pi/2 = +y, pi = -x, 3*pi/2 = -y)
rfPhase = -pi/2; 

[rf, gz] = mr.makeSincPulse(pi/2, sys, ...
    'Duration', rfDuration, ...
    'SliceThickness', sliceThickness, ...
    'timeBwProduct', timeBwProduct, ...
    'PhaseOffset', rfPhase, ...
    'use', 'excitation');

%% 2. Create Refocusing (Rephasing) Gradient
% The rephaser needs to cancel the phase dispersion from the second half 
% of the slice selection gradient.
refocusingFraction = 0.52
gzReph = mr.makeTrapezoid('z', sys, ...
    'Area', (-gz.area) * refocusingFraction  );

%% 3. Assemble Sequence Block(s)
% Block 1: RF excitation and slice selection gradient simultaneously
seq.addBlock(rf, gz);

% Block 2: Slice refocusing gradient
seq.addBlock(gzReph);

%% 4. Check Sequence & Write File
% Check system limits and timing
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing check passed successfully!\n');
else
    fprintf('Timing check failed:\n%s\n', error_report);
end


% Write to .seq file
seq.write('A6_sel_excitation.seq');

%% 5. Plot Sequence
seq.plot();
