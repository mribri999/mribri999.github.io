% Create a new Pulseq sequence object
seq = mr.Sequence();

seq.setDefinition('#SimmrDescription','Inversion:  A non-selective 180 RF pulse inverts the magnetization (pauses here).  After some amount of time (~0.7T1) the magnetization length on the left is zero (2nd pause), then continues to grow.  The spin on the right has longer T1, and never reaches its null.  Excitation at the null point can suppress a tissue.  Reducing the sphere size may help view.  Note rendering gray |M|.')
seq.setDefinition('# SimmrMatrixSize',' 1 1 1')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrView',' obl')
seq.setDefinition('# SimmrPause 2.1',' ');
seq.setDefinition('# SimmrPause 15',' ');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')
seq.setDefinition('# SimmrDfr', ' 0.0')
% Include each object's fields in the key so setDefinition retains both entries.
seq.setDefinition('# SimmrObject -100,0,0,20,10,"T1=20,T2=10ms",0,25,0', ' ')
seq.setDefinition('# SimmrObject 100,0,0,100,50,"T1=100,T2=50ms",0,25,0', ' ')
seq.setDefinition('# SimmrRendering','Gray |M|')


% Define System Specs (90 degree flip angle block pulse)
sys = mr.opts('maxGrad', 32, 'gradUnit', 'mT/m', ...
              'maxSlew', 130, 'slewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, 'rfDeadTime', 100e-6);

% Define durations and parameters
rf_duration = 2e-3;     % 2 ms RF pulse
delay_duration = 25e-3; % 25 ms delay
flip_angle = pi; % 90 degree excitation in radians

% Create a constant (block) RF pulse
% Note: mr.makeBlockPulse creates a rectangular/constant RF pulse
rfPhase = -pi/2;
rf = mr.makeBlockPulse(flip_angle, 'Duration', rf_duration, 'system', sys,...
	'PhaseOffset',rfPhase);

% Create the 3 ms delay block
delay = mr.makeDelay(delay_duration);

% Add blocks to the sequence
seq.addBlock(rf);    % Block 1: 2ms constant RF pulse
seq.addBlock(delay); % Block 2: 10ms delay

% Check sequence timing and validity
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing is valid.\n');
else
    fprintf('Sequence timing error: %s\n', error_report);
end

% Write the sequence to a Pulseq (.seq) file
seq.write('C4_inversion.seq');

% Plot the sequence layout
%seq.plot();


