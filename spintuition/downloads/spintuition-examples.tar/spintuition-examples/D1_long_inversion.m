% Create a new Pulseq sequence object
seq = mr.Sequence();

seq.setDefinition('#SimmrDescription','Long Inversion:  Use one of the T1 phantoms, and in settings check you have gray|M| set to observe T1 contrast following inversion.')
seq.setDefinition('# SimmrMatrixSize',' 1 1 1')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 10')
seq.setDefinition('# SimmrT2',' 10')
seq.setDefinition('# SimmrView',' obl')
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')
seq.setDefinition('# SimmrDfr', ' 0.0')


% Define system specs for the non-selective inversion pulse
sys = mr.opts('maxGrad', 32, 'gradUnit', 'mT/m', ...
              'maxSlew', 130, 'slewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, 'rfDeadTime', 100e-6);

% Define durations and parameters
rf_duration = 2e-3;     % 2 ms RF pulse
sequence_duration = 2000e-3; % 2000 ms total, including RF dead/ringdown time
flip_angle = pi;       % 180 degree inversion in radians

% Create a constant (block) RF pulse
% Note: mr.makeBlockPulse creates a rectangular/constant RF pulse
rfPhase = -pi/2;
rf = mr.makeBlockPulse(flip_angle, 'Duration', rf_duration, 'system', sys,...
	'PhaseOffset',rfPhase);

% Fill the remaining duration with uninterrupted longitudinal recovery.
delay_duration = sequence_duration - mr.calcDuration(rf);
delay = mr.makeDelay(delay_duration);

% Add blocks to the sequence
seq.addBlock(rf);    % Block 1: 2 ms RF pulse plus RF guard time
seq.addBlock(delay); % Block 2: recovery to 2000 ms total

% Check sequence timing and validity
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing is valid.\n');
else
    disp(error_report);
    error('D1_long_inversion:InvalidTiming', 'Sequence timing is invalid.');
end

% Write the sequence to a Pulseq (.seq) file
seq.write('D1_long_inversion.seq');

% Plot the sequence layout
%seq.plot();
