% Create a new pulse sequence object
seq = mr.Sequence();

% Simmr metadata
seq.setDefinition('#SimmrDescription', 'GRADIENT ECHO:  Excitation, then a standard gradient echo')
seq.setDefinition('# SimmrMatrixSize',' 5 1 5')
seq.setDefinition('# SimmrDfr',' 0.0') 
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 40')
seq.setDefinition('# SimmrT2',' 20')
seq.setDefinition('# SimmrView',' cor')
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')

% Define system specifications 
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, 'rfDeadTime', 10e-6, ...
              'adcDeadTime', 10e-6);

% Define sequence parameters
fov = [220e-3, 220e-3]; % Field of view in meters
Nx = 36;               % Frequency encoding matrix size, just make lots of twists
flipAngle = -90;         % Flip angle in degrees
sliceThickness = 1e-2;  % Slice thickness in meters
TE = 4e-3;             % Target Echo Time in seconds

rfPhase = pi/2;

% 1. Create RF Pulse (Sinc pulse for slice excitation)
% Pulseq outputs the matched slice-select (gz) and rephaser (gzReph) directly
[rf, gz, gzReph] = mr.makeSincPulse(flipAngle * pi / 180, 'System', sys, ...
    'Duration', 2e-3, 'SliceThickness', sliceThickness, ...
    'PhaseOffset', rfPhase);

% 2. Create Readout (Frequency Encoding) Gradient and ADC
deltak = 1 / fov(1);
gx = mr.makeTrapezoid('x', 'System', sys, 'FlatArea', Nx * deltak, 'FlatTime', 3.2e-3);
adc = mr.makeAdc(Nx, 'System', sys, 'Duration', gx.flatTime, 'Delay', gx.delay);

% 3. Create Pre-phasing Gradient
gxPre = mr.makeTrapezoid('x', 'System', sys, 'Area', -gx.area / 2, 'Duration', 1e-3);

% 4. Calculate Delay for Echo Time (TE) alignment
tRF2End = rf.shape_dur / 2 - rf.delay; 
tBlock2 = max(mr.calcDuration(gxPre), mr.calcDuration(gzReph));
tReadCenter = gx.delay + gx.flatTime / 2;

delayTE = TE - (tRF2End + tBlock2 + tReadCenter);
assert(delayTE >= 0, 'Requested TE is too short for the hardware limits!');
delayBlock = mr.makeDelay(delayTE);

% 5. Assemble the Sequence Blocks
seq.addBlock(rf, gz);       % Block 1: RF & Slice Select
seq.addBlock(gxPre, gzReph);% Block 2: Readout pre-phase & Slice re-phase
seq.addBlock(delayBlock);   % Block 3: Delay for TE timing
seq.addBlock(gx, adc);      % Block 4: Readout & ADC

% ==========================================
% WRITE THE PULSEQ FILE
% ==========================================
% This creates 'single_tr_gre.seq' in your current working directory
seq.write('E_gradient_echo.seq');

% Optional: Plot the pulse timing diagram
seq.plot();

