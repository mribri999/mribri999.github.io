% Make all .seq files for Simmr bundle
% The .seq should be put in the Sequences (add to project).

A_polarization
A0_excitation
A1_precession
A2_x_gradient
A3_x_gradient2D
A4_y_gradient2D
A5_excite_relax
A6_sel_excitation
A7_complete

B_encoding
B1_2x1_encode
B2_2x2_encode
B3_5x5_encoding

C_excitation
C1_simple_sel_ex
C2_sinc_excitation
C3_spin_echo
C4_inversion
C5_excite_phase

D1_long_inversion
D2_long_TE
D_seq_scaling

E_cpmg
E_epi
E_gradient_echo
E_spiral

E_bssfp
