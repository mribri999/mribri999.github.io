



% Initialize Pulseq system defaults
sys = mr.opts();

% Create Pulseq sequence object
seq = mr.Sequence(sys);

seq.setDefinition('#SimmrDescription C_excitation:  These examples show basic intuition for selective excitation (RF and gradients), then a common refocused sinc excitation.  (Note: this example is blank - move to C1.)',' ');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')

% Add Inversion?
% Add Adiabatic?

% Define a 1 ms delay
delay1ms = mr.makeDelay(1e-3);

% Add the delay block to the sequence
seq.addBlock(delay1ms);

% Verify sequence timing
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing check passed!\n');
else
    fprintf('Sequence timing errors found:\n');
    disp(error_report);
end

% Write out Pulseq file
seq.write('C_excitation.seq');
fprintf('Successfully saved sequence to delay_1ms.seq\n');

