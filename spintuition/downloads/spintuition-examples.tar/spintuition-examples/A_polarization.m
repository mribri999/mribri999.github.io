% Create a new Pulseq sequence object
seq = mr.Sequence();

seq.setDefinition('#SimmrDescription','Polarization:  In a magnetic field, protons align with the magnetic field (B0), with an excess in one direction that is called magnetization or loosely as "spins" that act as small dipoles. The Next button moves to the next example.')
seq.setDefinition('# SimmrMatrixSize',' 1 1 1')
seq.setDefinition('# SimmrSpinInit',' random')
seq.setDefinition('# SimmrT1',' 3')
seq.setDefinition('# SimmrT2',' 2')
seq.setDefinition('# SimmrView',' obl')
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')



% Define the duration of the delay (10 milliseconds)
delay_duration = 10e-3; % 10 ms in seconds

% Create a delay block
delay = mr.makeDelay(delay_duration);

% Add the delay block to the sequence
seq.addBlock(delay);

% Check sequence timing and validity
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing is valid.\n');
else
    fprintf('Sequence timing error: %s\n', error_report);
end

% Write the sequence to a Pulseq (.seq) file
seq.write('A_polarization.seq');

