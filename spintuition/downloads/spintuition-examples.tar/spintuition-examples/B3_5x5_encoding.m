% Set system limits and defaults
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, ...
              'rfDeadTime', 10e-6, ...
              'adcDeadTime', 10e-6);

% Initialize Pulseq sequence object
seq = mr.Sequence(sys);

seq.setDefinition('#SimmrDescription','5x5 Encoding:  Now we will show ACTUAL 5x5 encoding.  The sequence pauses at each sample - press play to continue!  Note the configuration of the spins at each of the 25 samples.  A 5x5 Fourier Transform would reconstruct the image');

TR=8;
seq.setDefinition('# SimmrMatrixSize',' 5 5 1')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrLabFrame',' off');
seq.setDefinition('# SimmrView',' ax');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
for p=1:4
  trf = sprintf('#SimmrSpinInit z %d',p*TR);
  seq.setDefinition(trf,' ');
end;
 
for y=0:4
  for x=0:4
    tpause = sprintf('# SimmrPause %d',3+y*TR+x);
    seq.setDefinition(tpause,' '); 
  end;
end;


% -------------------------------------------------------------------------
% 1. Create RF Excitation (-y axis, 1ms duration)
% -------------------------------------------------------------------------
% -y phase is -90 degrees (-pi/2 radians)
% Using a simple block pulse with a 90-degree flip angle
rf = mr.makeBlockPulse(pi/2, 'Duration', 1e-3, 'PhaseOffset', -pi/2, 'system', sys);

% -------------------------------------------------------------------------
% 2. Create Gradients and ADC
% -------------------------------------------------------------------------
x_dep_area = -400;
x_read_area = -2*x_dep_area;
% X Dephaser Gradient (-0.2 1/m, 1ms duration)
gx_dephaser = mr.makeTrapezoid('x', 'Area', x_dep_area, 'Duration', 1e-3, 'system', sys);

% Maximum Y Phase Encoding Gradient (0.1 1/m max area, 1ms duration)
max_pe_area = abs(x_dep_area);
% Scaling factors requested: 0, 0.5, 1, -0.5, -1
pe_factors = [0, 0.5, 1, -0.5, -1];

% X Readout Gradient (0.2 1/m total area, 4ms duration)
gx_readout = mr.makeTrapezoid('x', 'Area', x_read_area, 'Duration', 4e-3, 'system', sys);

% ADC Readout (aligned with readout gradient duration)
% Setting 256 samples across 4ms
adc = mr.makeAdc(256, 'Duration', gx_readout.flatTime, 'Delay', gx_readout.riseTime, 'system', sys);

% Delays
delay1ms = mr.makeDelay(1e-3);
delay4ms = mr.makeDelay(4e-3);

% -------------------------------------------------------------------------
% 3. Assemble Sequence Loop (Repeated 5 times)
% -------------------------------------------------------------------------
for i = 1:length(pe_factors)
    % 1. Excitation block (1ms RF pulse about -y)
    seq.addBlock(rf);
    
    % 2. 1ms Pause
    seq.addBlock(delay1ms);
    
    % 3. Simultaneous X Dephaser and Y Phase Encoding
    current_pe_area = max_pe_area * pe_factors(i);
    
    if current_pe_area ~= 0
        gy_pe = mr.makeTrapezoid('y', 'Area', current_pe_area, 'Duration', 1e-3, 'system', sys);
        seq.addBlock(gx_dephaser, gy_pe);
    else
        % When scale factor is 0, only apply X dephaser
        seq.addBlock(gx_dephaser);
    end
    
    % 4. 4ms Readout (X Readout + ADC)
    seq.addBlock(gx_readout, adc);
    
    % 5. 1ms Delay
    seq.addBlock(delay1ms);
end

% -------------------------------------------------------------------------
% 4. Check Sequence and Export .seq File
% -------------------------------------------------------------------------
% Verify gradient timing and hardware limits
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing check passed successfully!\n');
else
    fprintf('Sequence timing errors found:\n');
    disp(error_report);
end

% Plot sequence timing diagram
seq.plot();

% Write out Pulseq file
seq.write('B3_5x5_encoding.seq');
fprintf('Successfully saved sequence to custom_sequence.seq\n');

