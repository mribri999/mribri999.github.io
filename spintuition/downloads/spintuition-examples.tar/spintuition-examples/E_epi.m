% -------------------------------------------------------------------------
% Pulseq Script: Non-selective 90-degree excitation + EPI readout
% RF: 1 ms block pulse | FOV = 25 cm | resolution = 2.5 cm (10x10)
% Echo spacing = 2 ms | 10 readout echoes (one per ky line)
% -------------------------------------------------------------------------

% Define system limits
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, ...
              'rfDeadTime', 10e-6, ...
              'adcDeadTime', 10e-6, ...
              'adcSamplesDivisor', 1);      % allow Nx = 10 ADC samples

% Initialize sequence object
seq = mr.Sequence(sys);

% Simmr metadata
seq.setDefinition('#SimmrDescription','EPI:  A non-selective 90-degree excitation is followed by an echo-planar readout.  The readout gradient alternates polarity every 2 ms, and small y-gradient blips between echoes step through 10 lines of k-space after a single excitation.')
seq.setDefinition('# SimmrMatrixSize',' 10 10 1')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrLabFrame',' off')
seq.setDefinition('# SimmrView',' ax')
seq.setDefinition('# SimmrGradScale',' 1.0');	% Already scaled!
seq.setDefinition('# SimmrCategory ',' Advanced');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
% 1. Sequence Parameters
fov = 250e-3;            % Field of view: 25 cm
dx = 25e-3;              % Spatial resolution: 2.5 cm
Nx = round(fov / dx);    % 10 readout samples
Ny = 10;                 % 10 readout echoes (phase-encode lines)
echoSpacing = 2e-3;      % Echo spacing: 2 ms

% 2. Excitation Pulse (Non-selective 90 degree block pulse)
rfDuration = 1e-3;       % 1 ms duration
rf = mr.makeBlockPulse(pi/2, sys, 'Duration', rfDuration, 'use', 'excitation');

% 3. Readout & Phase Encoding Gradients
% K-space raster step sizes
dkx = 1 / fov;
dky = 1 / fov;

% Readout Gradient (Gx): each lobe (ramps + flat) lasts one echo spacing
gxRampTime = 0.2e-3;                         % scaled with echo spacing
gxFlatTime = echoSpacing - 2 * gxRampTime;   % 1.6 ms
gx = mr.makeTrapezoid('x', sys, 'FlatArea', Nx * dkx, ...
                      'FlatTime', gxFlatTime, 'RiseTime', gxRampTime);

% ADC samples the flat top of each readout lobe
adcDwell = gxFlatTime / Nx;                  % 160 us
adc = mr.makeAdc(Nx, sys, 'Dwell', adcDwell, 'Delay', gx.riseTime);

% Phase Encoding Blip Gradient (Gy), centered on the gap between lobes.
% Split it in half so the first half ends one readout block and the
% second half starts the next one.
blipDuration = 2 * gxRampTime;               % 0.4 ms
gyBlip = mr.makeTrapezoid('y', sys, 'Area', dky, 'Duration', blipDuration);
gyParts = mr.splitGradientAt(gyBlip, blipDuration / 2, sys);
[gyBlipUp, gyBlipDown, ~] = mr.align('right', gyParts(1), 'left', gyParts(2), gx);
gyBlipDownUp = mr.addGradients({gyBlipDown, gyBlipUp}, sys);

% Prephasing Gradients (Gx and Gy prephasers to reach k-space corner)
gxPre = mr.makeTrapezoid('x', sys, 'Area', -gx.area / 2, 'Duration', 0.5e-3);
gyPre = mr.makeTrapezoid('y', sys, 'Area', -Ny / 2 * dky, 'Duration', 0.5e-3);

% 4. Assemble the Sequence Blocks
seq.addBlock(rf);              % Non-selective 90-degree excitation
seq.addBlock(gxPre, gyPre);    % Move to the k-space corner

for iy = 1:Ny
    if iy == 1
        gyCurrent = gyBlipUp;      % first echo: only the leading blip half
    elseif iy == Ny
        gyCurrent = gyBlipDown;    % last echo: only the trailing blip half
    else
        gyCurrent = gyBlipDownUp;  % middle echoes: finish one blip, start next
    end
    seq.addBlock(gx, gyCurrent, adc);
    gx.amplitude = -gx.amplitude;  % alternate readout polarity
end

% 5. Check and Output Sequence File
[ok, errorReport] = seq.checkTiming;
if ~ok
    fprintf('Timing check failed:\n');
    fprintf([errorReport{:}]);
end

seq.write('E_epi.seq');
fprintf('Saved sequence to E_epi.seq\n');

% 6. Plot sequence timing & k-space trajectory
seq.plot();
% (seq.calculateKspacePP needs the Curve Fitting Toolbox, so integrate the
% piecewise-linear gradient waveforms directly: k resets to 0 at each
% excitation and is negated (k -> -k) at each refocusing pulse.)
[w, tex, tref, t_adc] = seq.waveforms_and_times();
tex = tex(1,:);
if isempty(tref), tref = []; else, tref = tref(1,:); end
tk = unique([w{1}(1,:), w{2}(1,:), tex, tref, t_adc]);
tk = tk(tk >= tex(1));
g = zeros(2, numel(tk));
for d = 1:2
    if ~isempty(w{d})
        [tg, ig] = unique(w{d}(1,:));
        g(d,:) = interp1(tg, w{d}(2,ig), tk, 'linear', 0);
    end
end
dk = diff(tk) .* (g(:,1:end-1) + g(:,2:end)) / 2;
ktraj = zeros(2, numel(tk));
for i = 2:numel(tk)
    ktraj(:,i) = ktraj(:,i-1) + dk(:,i-1);
    if any(tk(i) == tref), ktraj(:,i) = -ktraj(:,i); end
    if any(tk(i) == tex),  ktraj(:,i) = 0;           end
end
ktraj_adc = interp1(tk, ktraj.', t_adc).';
figure; plot(ktraj(1,:), ktraj(2,:), 'b'); hold on;
plot(ktraj_adc(1,:), ktraj_adc(2,:), 'r.'); axis equal;
xlabel('k_x (1/m)'); ylabel('k_y (1/m)'); title('EPI k-space trajectory');
