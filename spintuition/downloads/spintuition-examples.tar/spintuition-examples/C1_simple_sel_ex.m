
% C1_simple_sel_ex.m
% Simple Pulseq sequence with two 45-degree (-y) RF pulses and a Z-gradient in between.

%% 1. Initialize System and Sequence Objects
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, 'rfDeadTime', 10e-6, ...
              'adcDeadTime', 10e-6);

seq = mr.Sequence(sys);

seq.setDefinition('#SimmrDescription','Simple Selective Excitation Example:  If we apply two 45-degree tips with a gradient in between, the spins at z=0 will be tipped 90 degrees, while those off-axis are not tipped!  Adding more spins to the matrix in z shows that this not give a sharp slice - that is next.')

seq.setDefinition('# SimmrMatrixSize',' 3 1 3')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrDf',' 0.0')
seq.setDefinition('# SimmrLabFrame',' off')
seq.setDefinition('# SimmrView',' cor')
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')


%% 2. Define Parameters
rf_dur = 1e-3;      % 1 ms
grad_dur = 1e-3;    % 1 ms
flip_angle = 45;    % 45 degrees
phase_angle = -pi/2; % -y direction corresponds to -90 degrees (-pi/2)

grad_area = 200 

% Create phase encoding gradient blocks


%% 3. Create RF Pulse
% Block RF pulse: 45 degree flip angle, -y phase, 1ms duration
rf = mr.makeBlockPulse(flip_angle * pi / 180, sys, ...
                       'Duration', rf_dur, ...
                       'PhaseOffset', phase_angle);

%% 4. Create Z Gradient
% Trapezoidal gradient block along Z
gz = mr.makeTrapezoid('z', 'Area', grad_area, 'Duration',grad_dur, 'System', sys);

%% 5. Assemble Sequence
% Step 1: First RF Pulse (-y, 45 deg, 1 ms)
seq.addBlock(rf);

% Step 2: Z Gradient (0.25 kHz/m, 1 ms)
seq.addBlock(gz);

% Step 3: Second RF Pulse (-y, 45 deg, 1 ms)
seq.addBlock(rf);

%% 6. Check Sequence and Write File
% Verify timing and hardware constraints
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing check passed successfully!\n');
else
    fprintf('Sequence timing check failed:\n');
    disp(error_report);
end

% Write Pulseq sequence file
seq.write('C1_simple_sel_ex.seq');
fprintf('Sequence successfully saved to C1_simple_sel_ex.seq\n');

%% 7. Plot Sequence
seq.plot();
