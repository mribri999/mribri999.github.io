% -------------------------------------------------------------------------
% Pulseq Script: RF phase demonstration
% Five 1 ms, 90-degree constant-amplitude (block) RF pulses with phases
% 0, pi/2, pi, pi/6, pi/3.  Magnetization is reset to z at the start of
% each pulse, so each pulse tips M from z about a different axis.
% -------------------------------------------------------------------------

% Define system limits
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, ...
              'rfDeadTime', 10e-6, ...
              'adcDeadTime', 10e-6);

% Initialize sequence object
seq = mr.Sequence(sys);

% 1. Sequence Parameters
rfDuration = 1e-3;                       % 1 ms RF pulses
rfPhases = [0, pi/2, pi, pi/6, pi/3];    % RF phase of each pulse (rad)
TR = 3e-3;                               % Time from one pulse to the next
nPulses = length(rfPhases);

% Simmr metadata (1 spin, long T1/T2, rotating frame)
seq.setDefinition('#SimmrDescription','RF Phase:  The RF phase defines the angle of the rotation axis about which the magnetization tips.  Five 90-degree RF pulses are played, with the magnetization reset to z before each one.  The RF phases are 0, 90, 180, then 30 and 60 degrees (note the phase on the RF waveform), which sets the axis of rotation for the RF field, thus the direction into which magnetization is tipped.  Any RF phase can be used, not just multiples of 90 degrees.')
seq.setDefinition('# SimmrMatrixSize',' 1 1 1')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 200')
seq.setDefinition('# SimmrT2',' 50')
seq.setDefinition('# SimmrLabFrame',' off')
seq.setDefinition('# SimmrView',' obl')
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')

% 2. Build the RF pulses and the delay that fills each TR
for n = 1:nPulses
    rf(n) = mr.makeBlockPulse(pi/2, sys, 'Duration', rfDuration, ...
                              'PhaseOffset', rfPhases(n), 'use', 'excitation');
end
delay = mr.makeDelay(TR - mr.calcDuration(rf(1)));

% 3. Assemble the Sequence Blocks, resetting M to z at each RF start (ms)
for n = 1:nPulses
    tRFStart = (n-1) * TR + rf(n).delay;
    seq.setDefinition(sprintf('# SimmrSpinInit z %g', tRFStart * 1e3), ' ');
    seq.addBlock(rf(n));
    seq.addBlock(delay);
end

% 4. Check and Output Sequence File
[ok, errorReport] = seq.checkTiming;
if ~ok
    fprintf('Timing check failed:\n');
    fprintf([errorReport{:}]);
end

seq.write('C5_excite_phase.seq');
fprintf('Saved sequence to C_excite_phase.seq\n');

% 5. Plot sequence timing
seq.plot();
