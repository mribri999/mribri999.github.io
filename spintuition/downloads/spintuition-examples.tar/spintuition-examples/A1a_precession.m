% A1_precession
%
% This sequence does nothing for 10ms.
% It starts magnetization along x so that it can precess
% in the lab frame.
% 
% Create a new Pulseq sequence object
seq = mr.Sequence();

seq.setDefinition('#SimmrDescription','Precession: In the rotating frame, you do not observe precession because the frame itself is rotating at that rate.  This is the common frame for MRI as it is simpler.')

seq.setDefinition('# SimmrMatrixSize',' 1 1 1')
seq.setDefinition('# SimmrSpinInit',' x')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrDf',' 0.0')
seq.setDefinition('# SimmrLabFrame',' off')
seq.setDefinition('# SimmrView',' obl')
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')



% Define the duration of the delay (10 milliseconds)
delay_duration = 10e-3; % 10 ms in seconds

% Create a delay block
delay = mr.makeDelay(delay_duration);

% Add the delay block to the sequence
seq.addBlock(delay);

% Check sequence timing and validity
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing is valid.\n');
else
    fprintf('Sequence timing error: %s\n', error_report);
end

% Write the sequence to a Pulseq (.seq) file
seq.write('A1a_precession.seq');

