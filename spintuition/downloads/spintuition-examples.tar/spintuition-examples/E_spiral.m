% -------------------------------------------------------------------------
% Pulseq Script: Non-selective 90-degree excitation + single spiral readout
% RF: 1 ms block pulse | FOV = 25 cm | resolution = 2.5 cm (10x10)
% Single-shot spiral-out from k-space center, designed with vds.m.
% Gradient amplitude and slew are matched to the E_epi.m readout lobes.
% -------------------------------------------------------------------------

% Define system limits
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, ...
              'rfDeadTime', 10e-6, ...
              'adcDeadTime', 10e-6, ...
              'adcSamplesDivisor', 1);      % allow any ADC sample count

% Initialize sequence object
seq = mr.Sequence(sys);

% Simmr metadata
seq.setDefinition('#SimmrDescription','Spiral:  A non-selective 90-degree excitation is followed by a single spiral readout.  The x and y gradients oscillate together so that k-space is covered by a spiral that starts at the center and winds outward, covering the same 10x10 k-space as the EPI example in one shot.')
seq.setDefinition('# SimmrMatrixSize',' 10 10 1')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrLabFrame',' off')
seq.setDefinition('# SimmrView',' ax')
seq.setDefinition('# SimmrGradScale',' 1.0')
seq.setDefinition('# SimmrCategory ',' Advanced');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')

% 1. Sequence Parameters
fov = 250e-3;            % Field of view: 25 cm
dx = 25e-3;              % Spatial resolution: 2.5 cm
Nx = round(fov / dx);    % 10x10 matrix
dkx = 1 / fov;
kmax = 1 / (2 * dx);     % k-space radius to cover (1/m)

% Spiral gradient limits, matched to E_epi.m (1.6 ms flat top, 0.2 ms ramps)
gMax = Nx * dkx / 1.6e-3;          % Hz/m  (EPI readout amplitude)
sMax = gMax / 0.2e-3;              % Hz/m/s (EPI readout slew)
HzmPerGcm = sys.gamma * 1e-2;      % 1 G/cm = 1e-2 T/m

% 2. Excitation Pulse (Non-selective 90 degree block pulse)
rfDuration = 1e-3;       % 1 ms duration
rf = mr.makeBlockPulse(pi/2, sys, 'Duration', rfDuration, 'use', 'excitation');

% 3. Spiral Readout Gradients
% vds.m works in G/cm, G/cm/s and cm^-1.  Design on a fine 1 us grid,
% then resample k(t) onto the gradient raster.  (evalc hides vds output,
% and its diagnostic plot goes to a figure that is closed right after.)
assert(exist('vds', 'file') > 0, 'vds.m must be on the MATLAB path');
hf = figure;
evalc('[kSp, ~, ~, tSp] = vds(sMax / HzmPerGcm, gMax / HzmPerGcm, 1e-6, 1, fov * 100, kmax / 100);');
close(hf);

raster = sys.gradRasterTime;
nSp = floor(tSp(end) / raster);          % spiral length in raster steps
tGrad = (0:nSp) * raster;
kx = interp1([0 tSp], [0 real(kSp)], tGrad, 'pchip') * 100;   % 1/m
ky = interp1([0 tSp], [0 imag(kSp)], tGrad, 'pchip') * 100;

% Gradient (Hz/m) on raster centers, from the k-space steps
gx = diff(kx) / raster;
gy = diff(ky) / raster;

% Linear ramp-down to zero at the end of the spiral (slew-limited)
nRamp = ceil(max(abs([gx(end) gy(end)])) / (sMax * raster));
ramp = (nRamp-1:-1:0) / nRamp;
gx = [gx, gx(end) * ramp];
gy = [gy, gy(end) * ramp];

gxSp = mr.makeArbitraryGrad('x', gx, sys, 'first', 0, 'last', 0);
gySp = mr.makeArbitraryGrad('y', gy, sys, 'first', 0, 'last', 0);

% ADC samples the spiral (not the ramp-down)
adcDwell = 100e-6;
adcDelay = sys.adcDeadTime;
nAdc = floor((nSp * raster - adcDelay) / adcDwell);
adc = mr.makeAdc(nAdc, sys, 'Dwell', adcDwell, 'Delay', adcDelay);

% 4. Assemble the Sequence Blocks
seq.addBlock(rf);                  % Non-selective 90-degree excitation
seq.addBlock(gxSp, gySp, adc);     % Spiral-out readout

% 5. Check and Output Sequence File
[ok, errorReport] = seq.checkTiming;
if ~ok
    fprintf('Timing check failed:\n');
    fprintf([errorReport{:}]);
end

seq.write('E_spiral.seq');
fprintf('Saved sequence to E_spiral.seq (spiral readout %.2f ms, %d ADC samples)\n', ...
        nSp * raster * 1e3, nAdc);

% 6. Plot sequence timing & k-space trajectory
seq.plot();
% (seq.calculateKspacePP needs the Curve Fitting Toolbox, so integrate the
% piecewise-linear gradient waveforms directly: k resets to 0 at each
% excitation and is negated (k -> -k) at each refocusing pulse.)
warning('OFF', 'mr:restoreShape');   % benign for spirals (per Pulseq)
[w, tex, tref, t_adc] = seq.waveforms_and_times();
tex = tex(1,:);
if isempty(tref), tref = []; else, tref = tref(1,:); end
tk = unique([w{1}(1,:), w{2}(1,:), tex, tref, t_adc]);
tk = tk(tk >= tex(1));
g = zeros(2, numel(tk));
for d = 1:2
    if ~isempty(w{d})
        [tg, ig] = unique(w{d}(1,:));
        g(d,:) = interp1(tg, w{d}(2,ig), tk, 'linear', 0);
    end
end
dk = diff(tk) .* (g(:,1:end-1) + g(:,2:end)) / 2;
ktraj = zeros(2, numel(tk));
for i = 2:numel(tk)
    ktraj(:,i) = ktraj(:,i-1) + dk(:,i-1);
    if any(tk(i) == tref), ktraj(:,i) = -ktraj(:,i); end
    if any(tk(i) == tex),  ktraj(:,i) = 0;           end
end
ktraj_adc = interp1(tk, ktraj.', t_adc).';
figure; plot(ktraj(1,:), ktraj(2,:), 'b'); hold on;
plot(ktraj_adc(1,:), ktraj_adc(2,:), 'r.'); axis equal;
xlabel('k_x (1/m)'); ylabel('k_y (1/m)'); title('Spiral k-space trajectory');
