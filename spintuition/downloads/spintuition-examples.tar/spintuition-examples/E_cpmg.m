% -------------------------------------------------------------------------
% Pulseq Script: CPMG spin-echo train
% 90 (phase -pi/2) excitation, then refocusing pulses 150, 120, 120, 120, 120
% (phase 0).  All RF pulses are 1 ms non-selective block pulses.
% Echo spacing = 5 ms | FOV = 25 cm | resolution = 6.25 cm (4 samples in x)
% Each echo: x dephase + y phase encode, x readout, x rephase + y rewind.
% A constant 100 Hz/m z gradient plays through the whole sequence.
% -------------------------------------------------------------------------

% Define system limits
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, ...
              'rfDeadTime', 10e-6, ...
              'adcDeadTime', 10e-6);

% Initialize sequence object
seq = mr.Sequence(sys);

% Simmr metadata (T1 and T2 at the Simmr maximums: 200 ms and 50 ms)
seq.setDefinition('#SimmrDescription','CPMG:  A 90-degree followed by a train of refocusing pulses (150, then 120 degrees) every 5 ms includes Cartesian readouts (rewound for each spin echo for visibility).  After viewing, try adding z-spins to see the impact of off-resonance (constant z gradient).')
seq.setDefinition('# SimmrMatrixSize',' 5 5 1')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 200')
seq.setDefinition('# SimmrT2',' 50')
seq.setDefinition('# SimmrLabFrame',' off')
seq.setDefinition('# SimmrView',' ax')
seq.setDefinition('# SimmrGradScale',' 1.0');   % Already scaled!
seq.setDefinition('# SimmrCategory ',' Advanced');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')


% 1. Sequence Parameters
fov = 250e-3;                    % Field of view: 25 cm
dx = 62.5e-3;                    % Spatial resolution: 6.25 cm
Nx = round(fov / dx);            % 4 readout samples
dkx = 1 / fov;
dky = 1 / fov;
echoSpacing = 5e-3;              % Echo spacing: 5 ms
rfDuration = 1e-3;               % All RF pulses: 1 ms
refocusFlips = [150 120 120 120 120];   % degrees
nEchoes = length(refocusFlips);
kyIndex = (1:nEchoes) - 3;       % ky = -2, -1, 0, +1, +2 (x dky)
Gz = 1000;                        % Constant z gradient (Hz/m)
raster = sys.gradRasterTime;

% 2. RF Pulses (non-selective block pulses, CPMG phases)
rfExc = mr.makeBlockPulse(pi/2, sys, 'Duration', rfDuration, ...
                          'PhaseOffset', -pi/2, 'use', 'excitation');
for n = 1:nEchoes
    rfRef(n) = mr.makeBlockPulse(refocusFlips(n) * pi/180, sys, ...
                                 'Duration', rfDuration, ...
                                 'PhaseOffset', 0, 'use', 'refocusing');
end

% 3. Readout, Dephase/Rephase and Phase Encode Gradients
gxFlatTime = 2e-3;
gx = mr.makeTrapezoid('x', sys, 'FlatArea', Nx * dkx, ...
                      'FlatTime', gxFlatTime, 'RiseTime', 0.1e-3);
adc = mr.makeAdc(Nx, sys, 'Dwell', gxFlatTime / Nx, 'Delay', gx.riseTime);

tPre = 0.6e-3;                   % dephase / rephase lobe duration
gxPre = mr.makeTrapezoid('x', sys, 'Area', -gx.area / 2, 'Duration', tPre);

% 4. Timing: RF centers at (n-1/2)*ESP after excitation, echoes at n*ESP
tRF = mr.calcDuration(rfExc);                       % RF block duration
rfCenter = rfExc.delay + mr.calcRfCenter(rfExc);    % center within block
tRead = mr.calcDuration(gx);
readCenter = gx.riseTime + gx.flatTime / 2;

tExcToRef = round((echoSpacing/2 - (tRF - rfCenter) - rfCenter) / raster) * raster;
tPreBlock = round((echoSpacing/2 - (tRF - rfCenter) - readCenter) / raster) * raster;
tPostBlock = round((echoSpacing/2 - (tRead - readCenter) - rfCenter) / raster) * raster;
assert(tPreBlock >= tPre && tPostBlock >= tPre, 'Echo spacing too short');

% 5. Assemble the Sequence Blocks (every block carries the constant Gz)
seq.addBlock(mr.makeExtendedTrapezoid('z', sys, 'times', [0 0.1e-3], ...
             'amplitudes', [0 Gz]));                % ramp up Gz
seq.addBlock(rfExc, zConst(Gz, tRF, sys));          % 90 excitation
seq.addBlock(zConst(Gz, tExcToRef, sys));           % wait to first refocus

for n = 1:nEchoes
    seq.addBlock(rfRef(n), zConst(Gz, tRF, sys));   % refocusing pulse

    % Dephase in x and phase encode in y
    preEvents = {gxPre, zConst(Gz, tPreBlock, sys)};
    if kyIndex(n) ~= 0
        preEvents{end+1} = mr.makeTrapezoid('y', sys, ...
                           'Area', kyIndex(n) * dky, 'Duration', tPre);
    end
    seq.addBlock(preEvents{:});

    seq.addBlock(gx, adc, zConst(Gz, tRead, sys));  % readout (spin echo)

    % Rephase in x and rewind the y phase encode
    postEvents = {gxPre, zConst(Gz, tPostBlock, sys)};
    if kyIndex(n) ~= 0
        postEvents{end+1} = mr.makeTrapezoid('y', sys, ...
                            'Area', -kyIndex(n) * dky, 'Duration', tPre);
    end
    seq.addBlock(postEvents{:});
end

seq.addBlock(mr.makeExtendedTrapezoid('z', sys, 'times', [0 0.1e-3], ...
             'amplitudes', [Gz 0]));                % ramp down Gz

% 6. Check and Output Sequence File
[ok, errorReport] = seq.checkTiming;
if ~ok
    fprintf('Timing check failed:\n');
    fprintf([errorReport{:}]);
end

seq.write('E_cpmg.seq');
fprintf('Saved sequence to E_cpmg.seq\n');

% 7. Plot sequence timing & k-space trajectory
seq.plot();
% (seq.calculateKspacePP needs the Curve Fitting Toolbox, so integrate the
% piecewise-linear gradient waveforms directly: k resets to 0 at each
% excitation and is negated (k -> -k) at each refocusing pulse.)
[w, tex, tref, t_adc] = seq.waveforms_and_times();
tex = tex(1,:);
if isempty(tref), tref = []; else, tref = tref(1,:); end
tk = unique([w{1}(1,:), w{2}(1,:), tex, tref, t_adc]);
tk = tk(tk >= tex(1));
g = zeros(2, numel(tk));
for d = 1:2
    if ~isempty(w{d})
        [tg, ig] = unique(w{d}(1,:));
        g(d,:) = interp1(tg, w{d}(2,ig), tk, 'linear', 0);
    end
end
dk = diff(tk) .* (g(:,1:end-1) + g(:,2:end)) / 2;
ktraj = zeros(2, numel(tk));
for i = 2:numel(tk)
    ktraj(:,i) = ktraj(:,i-1) + dk(:,i-1);
    if any(tk(i) == tref), ktraj(:,i) = -ktraj(:,i); end
    if any(tk(i) == tex),  ktraj(:,i) = 0;           end
end
ktraj_adc = interp1(tk, ktraj.', t_adc).';
figure; plot(ktraj(1,:), ktraj(2,:), 'b'); hold on;
plot(ktraj_adc(1,:), ktraj_adc(2,:), 'r.'); axis equal;
xlabel('k_x (1/m)'); ylabel('k_y (1/m)'); title('CPMG k-space trajectory');

% -------------------------------------------------------------------------
% Constant z gradient lasting one whole block
function gz = zConst(G, dur, sys)
    gz = mr.makeExtendedTrapezoid('z', sys, 'times', [0 dur], ...
                                  'amplitudes', [G G]);
end
