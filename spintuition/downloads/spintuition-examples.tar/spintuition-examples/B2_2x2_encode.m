
% Create a new Pulseq sequence object
seq = mr.Sequence();


seq.setDefinition('#SimmrDescription','2x2 Phase Encoding:  Here we expand the last example to 2D (x and y).  We see 4 intervals (3ms) where a 2x2 array of spins (A,B,C,D) are encoded with signals A+B+C+D, i(A-B+C-D), i(A+B-C-D) and A-B-C+D.  These can be inverted to determine amplitudes of signals at A,B,C and D, a 2x2 Fourier transform!  ')

seq.setDefinition('# SimmrRendering','Phase Gray')
seq.setDefinition('# SimmrMatrixSize',' 2 2 1')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrLabFrame',' off');
seq.setDefinition('# SimmrView',' ax');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')

% Define system properties (using standard limits)
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, 'rfDeadTime', 100e-6, ...
              'adcDeadTime', 10e-6);

% 1. Create a 90-degree excitation RF pulse (1 ms duration)
% Standard 90 degree flip angle in radians = pi/2
rf = mr.makeBlockPulse(pi/2, 'Duration', 1e-3, 'PhaseOffset', -pi/2,'System', sys);

% Define common delays and gradients
delay3ms = mr.makeDelay(3e-3); % 3 ms pause

% Phase encode gradient parameters (Area = 2 kHz/m * ms = 2000 Hz/m * s)
area_pos = 100;  % 0.1 kHz/m * ms
area_neg = -100; % -0.1 kHz/m * ms

% Create phase encoding gradient blocks
gx_pos = mr.makeTrapezoid('x', 'Area', area_pos, 'System', sys);
gx_neg = mr.makeTrapezoid('x', 'Area', area_neg, 'System', sys);
gy_pos = mr.makeTrapezoid('y', 'Area', area_pos, 'System', sys);

% --- Assemble Sequence Blocks ---

% (1) 90 degree excitation of width 1ms
seq.addBlock(rf);

% (2) 3ms pause
seq.addBlock(delay3ms);

% (3) X phase encode gradient of area +2 kHz/m*ms
seq.addBlock(gx_pos);

% (4) 3ms pause
seq.addBlock(delay3ms);

% (5) X phase encode area of -2 kHz/m*ms and Y phase encode area of +2 kHz/m*ms
seq.addBlock(gx_neg, gy_pos);

% (6) 3ms pause
seq.addBlock(delay3ms);

% (7) X phase encode gradient of area +2 kHz/m*ms
seq.addBlock(gx_pos);

% (8) 3ms pause
seq.addBlock(delay3ms);

% Check sequence timing validity and write output file
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing is valid. Writing file...\n');
    seq.write('B2_2x2_encode.seq');
else
    fprintf('Sequence timing error:\n');
    disp(error_report);
end

% Optional: Plot the sequence diagram
seq.plot();
