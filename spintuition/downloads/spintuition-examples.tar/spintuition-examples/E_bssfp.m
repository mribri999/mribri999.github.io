
% -------------------------------------------------------------------------
% Pulseq Script: 45-degree RF Excitation + Z-Spoiler Gradient
% TR = 4.0 ms | RF duration = 0.5 ms (starts at t = 0.5 ms)
% Spoiler: Z-axis at t = 3.0 ms, duration = 0.5 ms, area = 4 cycles/m
% -------------------------------------------------------------------------

% 1. Initialize system limits and sequence object
sys = mr.opts('MaxGrad', 32, 'GradUnit', 'mT/m', ...
              'MaxSlew', 130, 'SlewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, 'rfDeadTime', 10e-6, ...
              'adcDeadTime', 10e-6);
seq = mr.Sequence(sys);



% Simmr metadata
seq.setDefinition('#SimmrDescription', 'Balanced SSFP:  From equilibrium, spins excite, precess, and relax toward a repeating steady state.')
seq.setDefinition('# SimmrMatrixSize',' 1 1 3')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 20')
seq.setDefinition('# SimmrT2',' 15')
seq.setDefinition('# SimmrView',' obl')
seq.setDefinition('# SimmrDfr', ' 0.0')
seq.setDefinition('# SimmrSS', '50');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')



% 2. Define sequence parameters
flipAngle = 45 * pi / 180; % Convert 45 degrees to radians
rf_dur    = 0.5e-3;        % RF pulse duration: 0.5 ms
TR        = 4.0e-3;        % Repetition time: 4.0 ms
N_rep     = 2;            % Number of repetitions

% 3. Create RF pulse
rf = mr.makeBlockPulse(flipAngle, sys, 'Duration', rf_dur);
rf1= mr.makeBlockPulse(-flipAngle, sys, 'Duration', rf_dur);

% 4. Create required delay blocks
delay1 = mr.makeDelay(0.5e-3); % 0.0 to 0.5 ms (before RF)
delay2 = mr.makeDelay(2.0e-3); % 1.0 to 3.0 ms (between RF end and spoiler start)
delay3 = mr.makeDelay(0.5e-3); % 3.5 to 4.0 ms (after spoiler end to finish TR)

% 5. Create Z-Spoiler Trapezoid Gradient
% 4 cycles/m = 4 1/m area in Pulseq units
spoiler_area     = 40;          % 4 cycles/m
spoiler_duration = 0.5e-3;     % Lasts 0.5 ms (3.0 ms to 3.5 ms)

gz_spoiler = mr.makeTrapezoid('z', sys, ...
    'Area', spoiler_area, ...
    'Duration', spoiler_duration);

% 6. Build sequence loop
for i = 1:N_rep
    % Block 1: 0.0 -> 0.5 ms
    seq.addBlock(delay1);
    
    % Block 2: 0.5 -> 1.0 ms (RF Excitation)
    if (rem(i,2)==1)
      seq.addBlock(rf);
    else
      seq.addBlock(rf1);
    end;
    
    % Block 3: 1.0 -> 3.0 ms
    seq.addBlock(delay2);
    
    % Block 4: 3.0 -> 3.5 ms (Z-Spoiler Gradient)
    seq.addBlock(gz_spoiler);
    
    % Block 5: 3.5 -> 4.0 ms
    seq.addBlock(delay3);
end

% 7. Verify timing and write to file
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing check passed successfully!\n');
    seq.write('E_bssfp.seq');
else
    fprintf('Sequence timing check failed:\n');
    disp(error_report);
end

% 8. Plot sequence timing
seq.plot();
