% Initialize Pulseq system defaults
sys = mr.opts();

% Create Pulseq sequence object
seq = mr.Sequence(sys);

seq.setDefinition('#SimmrDescription B_encoding:  These next exercises try to offer intuition for how images are encoded using gradient-induced phase.  You should exit from the expanded Spins view (top right) and load these in the Full view using the sequence icon at the top, then play.  B3 is a full 5x5 imaging sequence!  (Note: this example is blank.)',' ');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')


% Define a 1 ms delay
delay1ms = mr.makeDelay(1e-3);

% Add the delay block to the sequence
seq.addBlock(delay1ms);

% Verify sequence timing
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing check passed!\n');
else
    fprintf('Sequence timing errors found:\n');
    disp(error_report);
end

% Write out Pulseq file
seq.write('B_encoding.seq');
fprintf('Successfully saved sequence to delay_1ms.seq\n');

