% Create a new Pulseq sequence object
seq = mr.Sequence();

seq.setDefinition('#SimmrDescription','Excitation/Relaxation: Note the T2 decay of the transverse magnetization, and T1 recovery of longitudinal magnetization.  (You can vary these, and the sphere size later)')
seq.setDefinition('# SimmrMatrixSize',' 1 1 1')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 5')
seq.setDefinition('# SimmrT2',' 4')
seq.setDefinition('# SimmrView',' obl')
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')


% Define System Specs (30 degree flip angle block pulse)
sys = mr.opts('maxGrad', 32, 'gradUnit', 'mT/m', ...
              'maxSlew', 130, 'slewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, 'rfDeadTime', 100e-6);

% Define durations and parameters
rf_duration = 2e-3;     % 2 ms RF pulse
delay_duration = 10e-3; % 10 ms delay
flip_angle = 100 * pi / 180; % 90 degree excitation in radians
% (Allow for a bit of T2 decay during RF, reduces flip!)

% Create a constant (block) RF pulse
% Note: mr.makeBlockPulse creates a rectangular/constant RF pulse
rfPhase = -pi/2;
rf = mr.makeBlockPulse(flip_angle, 'Duration', rf_duration, 'system', sys,...
	'PhaseOffset',rfPhase);

% Create the 10 ms delay block
delay = mr.makeDelay(delay_duration);

% Add blocks to the sequence
seq.addBlock(rf);    % Block 1: 2ms constant RF pulse
seq.addBlock(delay); % Block 2: 10ms delay

% Check sequence timing and validity
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing is valid.\n');
else
    fprintf('Sequence timing error: %s\n', error_report);
end

% Write the sequence to a Pulseq (.seq) file
seq.write('A5_excite_relax.seq');

% Plot the sequence layout
%seq.plot();



