


% 1. Create Pulseq sequence object
sys = mr.opts('maxGrad', 40, 'gradUnit', 'mT/m', ...
              'maxSlew', 150, 'slewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, 'rfDeadTime', 100e-6);
seq = mr.Sequence(sys);

% Simmr metadata
seq.setDefinition('#SimmrDescription', 'Spin Echo:  A non-selective 90 excitation is followed by random, but repeatable dephasing.  A 180 refocusing pulse flips spins, and after some time, they will refocus to a spin echo.  Drag the play bar to observe the refocusing 180 degree pulse.  In the waveform panel controls you can modify Δf(r)σ to increase/decrease dephasing.')
seq.setDefinition('# SimmrMatrixSize',' 3 1 5')
seq.setDefinition('# SimmrSpinInit',' z')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrView',' cor')
seq.setDefinition('# SimmrDfr', ' 0.25')
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')
seq.setDefinition('# SimmrLabFrame',' off')

% 2. Define RF pulses (0.5 ms duration)
% 90 deg excitation about -y axis (phase = -pi/2 rad)
rf90 = mr.makeBlockPulse(pi/2, 'Duration', 0.5e-3, 'PhaseOffset', -pi/2, 'system', sys);

% 180 deg refocusing about +x axis (phase = 0 rad)
rf180 = mr.makeBlockPulse(pi, 'Duration', 0.5e-3, 'PhaseOffset', 0, 'system', sys);

% 3. Calculate timing durations
% RF 90 center to RF 180 center is 4 ms
delay1_dur = 4e-3 - (rf90.shape_dur/2) - (rf180.shape_dur/2); % 3.25 ms

% Total sequence duration is to spin echo.
delay2_dur = 4e-3 - (rf180.shape_dur/2); 

% 4. Calculate 10 mT/m gradient amplitude in Hz/m
gamma = 42.576e6; % Hz/T
%grad_amp = 1e-3 * gamma; % 10 mT/m converted to Hz/m
grad_amp = 0;	% Let it be just inhomogeneity...

% 5. Create flat gradient blocks matching each segment duration
gz_rf90   = mr.makeBlockPulse(0, 'Duration', rf90.shape_dur, 'system', sys); % placeholder for duration
gz_block1 = mr.makeTrapezoid('z', 'Amplitude', grad_amp, 'FlatTime', rf90.shape_dur, 'system', sys);
gz_block2 = mr.makeTrapezoid('z', 'Amplitude', grad_amp, 'FlatTime', delay1_dur,     'system', sys);
gz_block3 = mr.makeTrapezoid('z', 'Amplitude', grad_amp, 'FlatTime', rf180.shape_dur, 'system', sys);
gz_block4 = mr.makeTrapezoid('z', 'Amplitude', grad_amp, 'FlatTime', delay2_dur,    'system', sys);

% 6. Construct blocks containing both RF and corresponding Gradient segment
% Block 1: RF 90 + Gz
seq.addBlock(rf90, gz_block1);

% Block 2: Inter-pulse delay + Gz
seq.addBlock(gz_block2);

% Block 3: RF 180 + Gz
seq.addBlock(rf180, gz_block3);

% Block 4: Final delay + Gz
seq.addBlock(gz_block4);

% 7. Validate timing and export sequence
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing check passed successfully.\n');
    seq.write('C6_spin_echo.seq');
else
    fprintf('Sequence timing error:\n%s\n', error_report);
end

% 8. Plot resulting pulse sequence
seq.plot();
