% Create a new Pulseq sequence object
seq = mr.Sequence();

seq.setDefinition('#SimmrDescription','x Gradient (2D): An x-gradient (Gx) is turned on, but now note all spins along y for one x location rotate at the same rate.')

seq.setDefinition('# SimmrMatrixSize',' 5 5 1')
seq.setDefinition('# SimmrSpinInit',' x')
seq.setDefinition('# SimmrT1',' 100')
seq.setDefinition('# SimmrT2',' 40')
seq.setDefinition('# SimmrLabFrame',' off');
seq.setDefinition('# SimmrView',' obl');
seq.setDefinition('# SimmrAverageXYZ',' off')
seq.setDefinition('# SimmrAverageX',' off')
seq.setDefinition('# SimmrAverageY',' off')
seq.setDefinition('# SimmrAverageZ',' off')
seq.setDefinition('# SimmrShowB1',' off')
seq.setDefinition('# SimmrFadeUnexcited',' 0')

% Define System Specs
sys = mr.opts('maxGrad', 32, 'gradUnit', 'mT/m', ...
              'maxSlew', 130, 'slewUnit', 'T/m/s', ...
              'rfRingdownTime', 20e-6, 'rfDeadTime', 100e-6);



% Create a constant flat-top gradient along Gz concurrent with the RF pulse
% Calculate required gradient amplitude for the slice thickness (in Hz/m)
duration = 10e-3;      % 10 ms gradient
gx_amplitude = 20000;
gx = mr.makeTrapezoid('x', 'FlatArea', gx_amplitude * duration, ...
                      'FlatTime', duration, 'system', sys);


% Add blocks to the sequence
seq.addBlock(gx); % Gradient block.

% Check sequence timing and validity
[ok, error_report] = seq.checkTiming();
if ok
    fprintf('Sequence timing is valid.\n');
else
    fprintf('Sequence timing error: %s\n', error_report);
end

% Write the sequence to a Pulseq (.seq) file
seq.write('A3_x_gradient2D.seq');

% Plot the sequence layout
seq.plot();
